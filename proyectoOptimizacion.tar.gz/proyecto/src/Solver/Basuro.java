/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Solver;

/**
 *
 * @author hvar90
 */
public class Basuro {

    int posCities[] = {3, 7, 5, 6, 10, 6, 8, 10};
    int distance=0;
    int posDump[] = new int[2];
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
