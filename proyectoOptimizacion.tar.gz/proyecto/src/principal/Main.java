
package principal;

import Interfaz.VentanaPrincipal;

/**
 *
 * @author monki
 */
public class Main {
    
    public static void main(String [] args){
        VentanaPrincipal vp = new VentanaPrincipal();
        vp.setVisible(true);

                
    
    }
            
    
}
